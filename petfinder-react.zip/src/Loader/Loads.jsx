import React from "react";
/**
 *  Custom Loader in UI to show loading feature
 */
const Loader = () => {
  return <div className="loader" />;
};

export default Loader;
