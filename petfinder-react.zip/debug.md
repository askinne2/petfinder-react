# PetFinder React Plugin - Debugging Guide

## Common AJAX Issues

### Invalid Response Structure

If you're seeing "Invalid response structure" errors in the browser console, check:

1. **WordPress Response Format**
   - WordPress AJAX handlers use `wp_send_json_success()` or `wp_send_json_error()` to respond
   - Successful responses include `{success: true, data: yourData}`
   - Error responses include `{success: false, data: errorMessage}`

2. **Response Structure**
   - Verify the response matches what the frontend expects
   - For `get_animals`, response needs:
     - `animals` array
     - `pagination` object with `current_page` and `total_pages`
   - For `get_animal`, response needs the animal object with at least an `id` field

### Debugging Steps

1. **Enable Debug Mode**
   - Add to wp-config.php: 
     ```php
     define('WP_DEBUG', true);
     define('WP_DEBUG_LOG', true);
     ```

2. **Check Network Tab**
   - Open browser dev tools
   - Go to Network tab
   - Filter by "XHR" requests
   - Look for requests to admin-ajax.php
   - Inspect the response for any errors

3. **Verify Nonce**
   - Check that `ajaxNonce` is correctly passed to the frontend
   - Verify nonce is included in all AJAX requests as `nonce` parameter
   - Make sure nonce verification uses the same key: `petfinder_react_ajax_nonce`

4. **Test AJAX Directly**
   Using browser console:
   ```javascript
   const formData = new FormData();
   formData.append('action', 'petfinder_react_fetch_data');
   formData.append('action_type', 'get_animals');
   formData.append('nonce', petfinderReactVars.ajaxNonce);

   fetch(petfinderReactVars.ajaxUrl, {
     method: 'POST',
     credentials: 'same-origin',
     body: formData
   })
   .then(response => response.json())
   .then(data => console.log(data))
   .catch(error => console.error(error));
   ```

## PHP Error Logs

Check WordPress error logs (typically in /wp-content/debug.log) for PHP errors.

## Common Fixes

1. **Improper AJAX Response Format:**
   ```php
   // INCORRECT:
   echo json_encode($data);
   
   // CORRECT:
   wp_send_json_success($data);
   ```

2. **Missing wp_die():**
   Always end AJAX handlers with `wp_die()` to prevent extra output.

3. **Nonce Mismatch:**
   Ensure the same nonce name is used when creating and verifying.
